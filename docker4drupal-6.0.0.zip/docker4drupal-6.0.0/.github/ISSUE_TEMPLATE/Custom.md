---
name: Support request
about: Request support from community

---

***Codebase***
Built-in vanilla Drupal or mounted codebase

**Describe your issue**
A clear and concise description of your issue.

**Output of `docker info`**
```
Paste here
```

**Contents of your `docker-compose.yml`**
```
Paste here
```

**Contents of your `.env`**
```
Paste here
```

**Logs output `docker-compose logs`**
```
Paste here
```
