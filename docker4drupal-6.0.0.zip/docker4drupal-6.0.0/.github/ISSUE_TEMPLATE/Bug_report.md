---
name: Bug report
about: Create a report to help us improve

---

***OS type***
Linux/Windows/macOS

***Drupal version***
7 / 8

***Codebase***
Built-in vanilla Drupal or mounted codebase

**Describe the bug**
A clear and concise description of what the bug is.

**Output of `docker info`**
```
Paste here
```

**Contents of your `docker-compose.yml`**
```
Paste here
REMOVE COMMENTED LINES
```

**Contents of your `.env`**
```
Paste here
REMOVE COMMENTED LINES
```

**Logs output `docker-compose logs`**
```
Paste here
```
